<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tmbc extends CI_Controller {
	private $article_id = 1;//hardcodes article id for this demo.

	public function __construct(){
        parent::__construct();
        $this->load->model('Content_model', '', TRUE);
    }    

	public function index()
	{		
		$article = $this->Content_model->getArticle($this->article_id);
		$comments = $this->Content_model->getComments($this->article_id);

		$data = array(
			'article'=>$article, 
			'comments'=>$comments,
			'article_id'=>$this->article_id
		);
		
		$this->load->view('head');
		$this->load->view('index', $data);
		$this->load->view('footer');
	}

	public function refresh(){
		$comments = $this->Content_model->getComments($this->article_id);
		header('Content-Type: application/json');
		echo json_encode($comments);
	}

	public function comment(){
		$input = json_decode(file_get_contents("php://input"));
		$rv = $this->Content_model->addComment($input);
		header('Content-Type: application/json');
		echo $rv;		
	}
}
