<?php
class Content_model extends CI_Model
{
	function getArticle($id){
		$sql = "SELECT * FROM `articles` WHERE id = ?";
		$query = $this->db->query($sql, array($id));
        return $query->row_array();
	}

	function getComments($article_id){
		$rows = array();

		$sql = "SELECT `id`, `article_id`, `name`, `comment`, `parent_id`, `created` FROM `comments` WHERE `article_id` = ? ORDER BY `parent_id` ASC, `created` DESC";

		$query = $this->db->query($sql, array($article_id));

        foreach($query->result() as $row)
            $rows[] = $row;

        return $rows;
	}

	function addComment($a){
		$count = $this->countComments($a);

		if($count < 3){
			$this->db->insert('comments',$a);
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	function countComments($a){
		$sql = "SELECT COUNT(*) AS `count` FROM `comments` WHERE `parent_id` = ?";
		$query = $this->db->query($sql, array($a->parent_id));
		$row = $query->row_array();
		return $row['count'];
	}
}