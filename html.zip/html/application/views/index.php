<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>    
<!-- Page Content -->
<div class="container">
  <div class="row">
    <div class="col-lg-12">
    	<h4><? echo $article['title'];?></h4>
    	<div>Created <? echo $article['created'];?></div>
    	<div><? echo nl2br($article['article']);?></div>	
    	<div><button type="button" class="btn btn-primary btn-sm addComment" id="comment:0">Add Comment</button></div>
    	<div>&nbsp;</div>
    	<div class="relative" id="commentBoxDiv">
    		<div class="absolute" id="commentBox">
    			<div><input type="text" id="commentName" class="form-control spacer" placeholder="Your Name"/></div>
    			<div><input type="text" id="commentTxt" class="form-control spacer" placeholder="Your Comment"/></div>
    			<div>
    				<button type="button" class="btn btn-primary btn-sm spacer" id="submitComment">Submit Comment</button>
    				<button type="button" class="btn btn-primary btn-sm spacer" id="clearComment">Clear</button>
    			</div>
    			<div><input type="hidden" class="commentParentId" id="commentParentId" value=""/></div>	 
    			<div><input type="hidden" id="commentArticleId" value="<? echo $article_id;?>"/></div>	  			
    		</div>
    	</div>
  </div>
      <div class="col-lg-12">
      	<h6>Comments</h6>
        <div id="comments">
    	<?
    	foreach ($comments as $comment) {
    		echo '<hr>';
    		echo '<div>On '.$comment->created.' by '.$comment->name.'</div>';
    		echo '<div>'.nl2br($comment->comment).'</div>';
    		echo '<div><button type="button" class="btn btn-primary btn-sm addComment" id="comment:'.$comment->id.'">Add Comment</button></div>';
    	}
    	?>
        </div>
    </div>
    </div>
</div>