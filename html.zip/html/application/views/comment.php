<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>    
<!-- Page Content -->
<div class="container">
  <div class="row">
    <div class="col-lg-12">
        <? if(isset($id)) echo $id;?>
    	<form action="/comment" method="POST">
            <div><input type="text" name="name" class="form-control spacer" placeholder="Your Name"/></div>
            <div><input type="text" name="comment" class="form-control spacer" placeholder="Your Comment"/></div>
            <div><input type="text" name="article_id" class="form-control spacer" value="1"/></div>
            <div><input type="text" name="parent_id" class="form-control spacer" value="0"/></div>
            <div><input type="submit" class="btn btn-primary btn-sm spacer" value="Submit"/></div>
        </form>    
    </div>
    </div>
</div>