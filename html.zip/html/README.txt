The follwoing files are created by me.
html\application\config\routes.php
html\application\controllers\Tmbc.php
html\application\models\Content_model.php
html\application\views\comment.php //For testing only, not critical to demo.
html\application\views\head.php
html\application\views\footer.php
html\application\views\index.php
html\application\.htaccess
html\pigfoxco_tmbc.sql
html\css\index.css
html\js\index.js

You can drive the demo here.
https://tmbc.pigfox.com/