$(document).ready(function() {
  $(document).on('click', '.addComment', function() {
    $('#commentBox').show();
    var id = this.id;
    parts = id.split(':');
    $('#commentParentId').val(parts[1]);
  });

  $(document).on('click', '#clearComment', function() {
    $('#commentName').val('');
    $('#commentName').removeClass('is-invalid');
    $('#commentTxt').val('');
    $('#commentTxt').removeClass('is-invalid');
    $('#commentBox').hide();
  });

  $(document).on('click', '#submitComment', function() {
    var commentParentId = $('#commentParentId').val();
    var commentArticleId = $('#commentArticleId').val();

    var commentName = $('#commentName')
      .val().trim()
      .replace(/[^\w\s]/gi, '');

    var commentTxt = $('#commentTxt')
      .val().trim()
      .replace(/[^\w\s]/gi, '');

    if (commentName.length == 0) {
      $('#commentName').addClass('is-invalid');
      $('#commentName').val(''); // In case user has submitted garbage data that has been replaced above
      return false;
    }

    $('#commentName').removeClass('is-invalid');

    if (commentTxt.length == 0) {
      $('#commentTxt').addClass('is-invalid');
      $('#commentTxt').val(''); // In case user has submitted garbage data that has been replaced above
      return false;
    }

    $('#commentTxt').removeClass('is-invalid');

    //Manually creating the payload for debugging purposes
    var payload = '{"article_id"' + ':' + commentArticleId + ',"parent_id"' + ':' + commentParentId + ',"name"' + ':' + '"' + commentName + '"' + ',"comment"' + ':' + '"' + commentTxt + '"' + '}';

    function comment(){
      return $.ajax({
        async: true,
        type: 'POST',
        url: '/comment',
        dataType: 'json',
        data: payload
      }).done(function(data){
        if(!isNaN(data)){
          $('#commentName').val('');
          $('#commentTxt').val('');
          $('#commentBox').hide(); 
          return true;       
        }else{
          alert('Post failed');
          return false;
        }
      });
    }

    function reload(commentResult){
      if(!isNaN(commentResult)){
         $.ajax({
          async: true,
          type: 'GET',
          url: '/refresh',
          dataType: 'json'
        }).done(function(data){
          if(data){
            $('#comments').html('');
            var len = data.length;
            var html = '';
            for(var i = 0; i < len; i++){
              html += '<hr>';
              html += '<div>On ' + data[i].created + ' by ' + data[i].name + '</div>';
              html += '<div>' + data[i].comment.replace(/\n/g,"<br/>") + '</div>';
              html += '<div><button type="button" class="btn btn-primary btn-sm addComment" id="comment:'+ data[i].id +'">Add Comment</button></div>';
            }
            $('#comments').html(html);
            //alert(data);       
          }else{
            alert('Refesh failed');
            return false;
          }
        });
      }
    }

    comment().then(reload);
  });
});
